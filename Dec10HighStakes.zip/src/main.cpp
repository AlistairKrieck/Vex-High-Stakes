/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Alistair Krieck                                           */
/*    Created:      Mon Nov 25 2024                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Piston               digital_out   A
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "math.h"
#include "vex.h"

using namespace vex;

competition Comp;

controller Controller1;

motor L1 = motor(PORT1, ratio6_1, false);
motor L2 = motor(PORT2, ratio6_1, true);
motor L3 = motor(PORT3, ratio6_1, false);

motor R1 = motor(PORT14, ratio6_1, false);
motor R2 = motor(PORT12, ratio6_1, true);
motor R3 = motor(PORT13, ratio6_1, false);

motor Intake = motor(PORT6, ratio6_1, true);
motor Conveyor = motor(PORT4, ratio6_1, false);

motor_group leftMotors = motor_group(L1, L2, L3);
motor_group rightMotors = motor_group(R1, R2, R3);
motor_group DT = motor_group(L1, L2, L3, R1, R2, R3);
motor_group IntakeMotors = motor_group(Intake, Conveyor);

inertial Inertial = inertial(PORT10);

bool pistonState = true;

double PI = 3.14;
double wheelCircumferece = PI * 3.25; //= ~10.2 inches

static float KpDrive = 1.5;
static float KpTurn = 1;
static float Ki = 0.05;
static float Kd = 2;

double previousHeading = 0.0;
double currentDistance = 0.0;
double previousError = 0.0;
double integral = 0.0;

void changePistonState() {
  pistonState = !pistonState;
  Piston.set(pistonState);
}

void driverControl() {
  rightMotors.spin(fwd);
  leftMotors.spin(fwd);
  IntakeMotors.spin(fwd);

  while (true) {
    leftMotors.setVelocity(Controller1.Axis1.position() / 2 +
                               Controller1.Axis3.position(),
                           percent);
    rightMotors.setVelocity(Controller1.Axis1.position() / 2 -
                                Controller1.Axis3.position(),
                            percent);

    if (Controller1.ButtonR2.pressing() == true) {
      IntakeMotors.setVelocity(100, percent);
    } else if (Controller1.ButtonL2.pressing() == true) {
      IntakeMotors.setVelocity(-50, percent);
    } else {
      IntakeMotors.setVelocity(0, percent);
    }

    wait(10, msec);
  }
}

void DrivePID(int targetDistance, bool reversed) {
  // Variables
  double spinOutput = 0.0;
  double error = 0.0;
  int rev = 1;

  leftMotors.setRotation(0, deg);
  rightMotors.setRotation(0, deg);

  if (reversed == true) {
    rev = -1;
  }

  /*
  To stay straight:
  Read the angle of the bot using the inertial
  Apply a corrective vector in the opposite direction of the rotation (if past a
  deadband)
  */

  while (true) {
    // Get the current distance traveled by the motors (average of both sides)
    double currentDegrees = leftMotors.position(deg);
    double currentDistance =
        rev * (currentDegrees / 360.0) * (wheelCircumferece)*0.6;

    // Calculate distance error
    error = targetDistance - currentDistance;

    // Calculate motor power for distance
    double output = rev * KpDrive * error;

    // Check if the bot is straight, if not straighten it
    if (fabs(Inertial.rotation()) > 0.5) {
      double spinError = Inertial.rotation();
      spinOutput = KpTurn * spinError;
    }

    // Set motor power
    rightMotors.setVelocity(-output - spinOutput, percent);
    leftMotors.setVelocity(output + spinOutput, percent);

    // Break the loop if the distance error is small enough
    if (fabs(error) < 1) {
      break;
    }

    // Small delay to prevent overloading the CPU
    wait(20, msec);
  }

  // Stop Motors
  leftMotors.stop();
  rightMotors.stop();
}

void SpinPID(double targetDegrees, bool reversed) {
  double error = 0;
  int rev = 1;

  Inertial.setRotation(0, deg);

  if (reversed == true) {
    rev = -1;
  }

  while (true) {
    double currentDegrees = Inertial.rotation();
    error = targetDegrees + currentDegrees;
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(0, 0);
    wait(20, msec);
    Controller1.Screen.print(error);

    double output = KpTurn * error;

    // Set motor power
    rightMotors.setVelocity(output, percent);
    leftMotors.setVelocity(output * 0.9, percent);

    if (fabs(error) < 1) {
      break;
    }

    wait(20, msec);
  }
}

void Auton() {
  /* IF NO COLOUR SORT
  Move back 36 inches
  Grab MOGO
  Deposit preload
  Rotate 90 deg to face ring stack
  Drop MOGO to reduce weight
  Drive 24 inches forward to push off top ring and intake bottom ring
  Turn 45 degrees to face away from alliance wall stake
  Drive forward 4(sprt2) inches to reach AWS
  Rotate 45 degrees so back is to AWS
  Drive back closer to AWS
  Deposit ring on AWS
  Drive forward 36 inches to touch tower (just crash through rings who cares)
  */
  leftMotors.spin(forward, 0, pct);
  rightMotors.spin(forward, 0, pct);

  DrivePID(36, true);
  Piston.set(true);
  wait(20, msec);
  IntakeMotors.spin(fwd, 100, pct);
  wait(1, sec);
  SpinPID(90, false);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  Comp.autonomous(Auton);
  Comp.drivercontrol(driverControl);
  Controller1.ButtonA.pressed(changePistonState);

  Inertial.calibrate();
  while (Inertial.isCalibrating()) {
    wait(10, msec);
  }

  while (true) {
    wait(100, msec);
  }
}
