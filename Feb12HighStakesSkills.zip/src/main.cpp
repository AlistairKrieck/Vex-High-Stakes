/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Alistair Krieck                                           */
/*    Created:      Mon Nov 25 2024                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Piston               digital_out   A
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "math.h"
#include "vex.h"

using namespace vex;

competition Comp;

controller Controller1;

motor L1 = motor(PORT1, ratio6_1, false);
motor L2 = motor(PORT2, ratio6_1, true);
motor L3 = motor(PORT3, ratio6_1, false);

motor R1 = motor(PORT14, ratio6_1, false);
motor R2 = motor(PORT13, ratio6_1, true);
motor R3 = motor(PORT12, ratio6_1, false);

motor Intake = motor(PORT9, ratio6_1, true);

motor_group leftMotors = motor_group(L1, L2, L3);
motor_group rightMotors = motor_group(R1, R2, R3);
motor_group DT = motor_group(L1, L2, L3, R1, R2, R3);

// digital_out Piston = digital_out(Brain.ThreeWirePort.A);

inertial Inertial = inertial(PORT10);

bool pistonState = true;

double PI = 3.14;
double wheelCircumferece = PI * 3.25; //= ~10.2 inches

static float Kp = 2.5;
static float KpTurn = 0.5;
static float Ki = 0.05;
static float Kd = 2;

double previousHeading = 0.0;
double currentDistance = 0.0;
double previousError = 0.0;
double integral = 0.0;

void changePistonState() {
  pistonState = !pistonState;
  Piston.set(pistonState);
}

void Test()
{
  leftMotors.setVelocity(100, pct);
  rightMotors.setVelocity(-100, pct);
}

void driverControl() {
  rightMotors.spin(fwd);
  leftMotors.spin(fwd);
  Intake.spin(fwd);

  while (true) {
    leftMotors.setVelocity(-Controller1.Axis1.position() * 0.75 -
                               Controller1.Axis3.position(),
                           percent);
    rightMotors.setVelocity(-Controller1.Axis1.position() * 0.75 +
                                Controller1.Axis3.position(),
                            percent);

    if (Controller1.ButtonR2.pressing() == true) {
      Intake.setVelocity(100, percent);
    } else if (Controller1.ButtonL2.pressing() == true) {
      Intake.setVelocity(-50, percent);
    } else {
      Intake.setVelocity(0, percent);
    }

    if(Controller1.ButtonB.pressing() == true)
    {
      Test();
    }

    wait(10, msec);
  }
}

void DrivePID(double targetDistance, bool reversed) {
  // Variables
  double spinOutput = 0.0;
  double error = 0.0;
  double previousError = 0.0;
  double integral = 0.0;
  double derivitave = 0.0;
  int rev = 1;

  leftMotors.setPosition(0, deg);
  rightMotors.setPosition(0, deg);
  if (reversed == true) {
    rev = -1;
  }

  while (true) {
    // Get the current distance traveled by the motors (average of both sides)
    double currentDegrees = (leftMotors.position(deg) + rightMotors.position(deg)) / 2;
    double currentDistance =
        rev * (currentDegrees / 360.0) * (wheelCircumferece)*0.6;

    // Calculate distance error
    error = targetDistance - currentDistance;

    integral += error;
    derivitave = error - previousError;

    previousError = error;

    // Calculate motor power for distance
    double output = rev * (Kp * error + Ki * integral + Kd * derivitave);

    if(output > 100)
    {
      output = 100;
    }
    else if (output < -100)
    {
      output = -100;
    }

    // Set motor power
    rightMotors.setVelocity(-output - spinOutput, percent);
    leftMotors.setVelocity(output + spinOutput, percent);

    // Break the loop if the distance error is small enough
    if (fabs(error) < 0.5) {
      Controller1.Screen.print(error);
      break;
    }

    // Small delay to prevent overloading the CPU
    wait(20, msec);
  }

  // Stop Motors
  leftMotors.setVelocity(0, pct);
  rightMotors.setVelocity(0, pct);
}

void SpinPID(double targetDegrees) {
  double error = 0;

  Inertial.setRotation(0, deg);
  leftMotors.setVelocity(0, percent);
  rightMotors.setVelocity(0, percent);

  while (true) {
    if (Inertial.rotation() > 365) {
      Inertial.setRotation(0, deg);
    }

    double currentDegrees = Inertial.rotation();
    error = targetDegrees + currentDegrees;

    double output = KpTurn * error;

    // Set motor power
    rightMotors.setVelocity(output, percent);
    leftMotors.setVelocity(output, percent);

    if (fabs(error) < 1) {
      rightMotors.setVelocity(0, pct);
      leftMotors.setVelocity(0, pct);
      break;
    }

    wait(20, msec);
  }
}

void Auton() {
  /* IF NO COLOUR SORT
  Move back 36 inches
  Grab MOGO
  Deposit preload
  Rotate 90 deg to face ring stack
  Drop MOGO to reduce weight
  Drive 24 inches forward to push off top ring and intake bottom ring
  Turn 45 degrees to face away from alliance wall stake
  Drive forward 4(sprt2) inches to reach AWS
  Rotate 45 degrees so back is to AWS
  Drive back closer to AWS
  Deposit ring on AWS
  Drive forward 36 inches to touch tower (just crash through rings who cares)
  */
  Inertial.setRotation(0, deg);
  Inertial.setHeading(0, deg);
  leftMotors.spin(forward, 0, pct);
  rightMotors.spin(forward, 0, pct);

  Intake.spin(forward, 100, pct);

  DrivePID(1, false);
  // IntakeMotors.spin(fwd, 100, pct);
  // wait(1, sec);
  // IntakeMotors.spin(reverse, 50, pct);
  // wait(200, msec);
  // IntakeMotors.stop();
  // DrivePID(7.5, false);
  // IntakeMotors.spin(fwd, 100, pct);
  // SpinPID(-90);
  // DrivePID(12, true);
  // Piston.set(true);
  // SpinPID(90);
  // DrivePID(12, false);
  // SpinPID(90);
  // DrivePID(12, false);
  // SpinPID(90);
  // DrivePID(12, false);
  // SpinPID(-90);
  // DrivePID(6, false);
  // SpinPID(120);
  // DrivePID(8, false);
  // SpinPID(90);
  // DrivePID(6, true);
  // Piston.set(false);
  // DrivePID(5, false);
  // //Get to next MOGO
  // // DrivePID(27, false); // Drive halfway to MOGO
  // // SpinPID(10);
  // // DrivePID(27, true);
  // // Piston.set(true);
  // // // Repeat part 1 just reversed
  // // SpinPID(-90);
  // // DrivePID(12, false);
  // // SpinPID(-90);
  // // DrivePID(12, false);
  // // SpinPID(-90);
  // // DrivePID(12, false);
  // // SpinPID(90);
  // // DrivePID(6, false);
  // // SpinPID(-120);
  // // DrivePID(8, false);
  // // SpinPID(-90);
  // // DrivePID(6, true);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  Comp.autonomous(Auton);
  Comp.drivercontrol(driverControl);
  Controller1.ButtonA.pressed(changePistonState);

  Inertial.calibrate();
  while (Inertial.isCalibrating()) {
    wait(10, msec);
  }

  while (true) {
    wait(100, msec);
  }
}
